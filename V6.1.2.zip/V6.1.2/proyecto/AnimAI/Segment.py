import cvzone
import cv2
import tensorflow
from cvzone.ClassificationModule import Classifier

# Iniciar la captura de video desde la cámara
cap = cv2.VideoCapture(0)
# Cargar el modelo y las etiquetas
myClassifier = Classifier('MyModel/keras_model.h5', 'MyModel/labels.txt')

# Bucle principal
while True:
    # Leer fotogramas desde la cámara
    success, img = cap.read()
    if not success:
        break

    # Obtener predicciones del clasificador
    predictions, index = myClassifier.getPrediction(img)

    # Mostrar la imagen en una ventana
    cv2.imshow('image', img)

    # Esperar 1 milisegundo a que se presione una tecla
    if cv2.waitKey(1) == 27:  # Presionar 'ESC' para salir del bucle
        break

# Liberar la captura de video y cerrar todas las ventanas
cap.release()
cv2.destroyAllWindows()