from django.shortcuts import render, redirect
from .forms import testUser
from PIL import Image
from cvzone.ClassificationModule import Classifier
import numpy as np
def index(request):
    testT = testUser()
    myClassifier = Classifier('C:/Users/miasa/Desktop/V6.1.2/proyecto/AnimAI/mymodel/keras_model.h5', 'C:/Users/miasa/Desktop/V6.1.2/proyecto/AnimAI/mymodel/labels.txt')
# Cargar el modelo y las etiquetas
    return render(request, 'inicio.html',{"form" : testT})


def fun():
        image = Image.open("C:/Users/miasa/Downloads/beagle.jpg")
        npd = np.array(image)
       # Cargar el modelo y las etiquetas
        print("here")
        myClassifier = Classifier('C:/Users/miasa/Desktop/V6.1.2/proyecto/AnimAI/mymodel/keras_model.h5', 'C:/Users/miasa/Desktop/V6.1.2/proyecto/AnimAI/mymodel/labels.txt') # Obtener predicciones del clasificador
        predictions, index = myClassifier.getPrediction(npd)
        print(index)
        print(predictions)
        rimg = Image.fromarray(npd)
        rimg.show()