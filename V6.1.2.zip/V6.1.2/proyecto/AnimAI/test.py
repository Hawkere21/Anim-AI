import cvzone
import cv2
import tensorflow
from cvzone.ClassificationModule import Classifier
from PIL import Image
import numpy as np
# Iniciar la captura de video desde la cámara
class index:
    def fun():
        image = Image.open("C:/Users/miasa/Downloads/beagle.jpg")
        npd = np.array(image)
       # Cargar el modelo y las etiquetas
        myClassifier = Classifier('MyModel/keras_model.h5', 'MyModel/labels.txt')# Obtener predicciones del clasificador
        predictions, index = myClassifier.getPrediction(npd)
        print(index)
        print(predictions)
        rimg = Image.fromarray(npd)
        rimg.show()