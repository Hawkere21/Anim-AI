// Selecciona el botón y el elemento overlay
const toggleButton = document.getElementById('toggleButton');
const overlay = document.getElementById('overlay');

// Agrega un listener de evento al botón
toggleButton.addEventListener('click', function() {
    // Alterna la clase 'dark-mode' en el elemento overlay
    overlay.classList.toggle('dark-mode');
});
