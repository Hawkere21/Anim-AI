from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('registrarme.html', views.registrarme, name='registrarme'),
    path('index.html', views.index, name='index'),
    path('inicio.html', views.inicio, name='inicio'),
    path('configuracion.html', views.configuracion, name='configuracion'),
    path('inicio2.html', views.inicio2, name='inicio2'),
    path('configuracion2.html', views.configuracion2, name='configuracion2'),
    path('ver3d.html', views.ver3d, name='ver3d'),
    path('ver3d2.html', views.ver3d2, name='ver3d2'),
]
