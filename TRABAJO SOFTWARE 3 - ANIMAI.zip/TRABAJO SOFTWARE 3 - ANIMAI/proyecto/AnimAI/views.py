from django.shortcuts import render

from .models import MiModelo

def index(request):
    objetos = MiModelo.objects.all()
    return render(request, 'index.html', {'objetos': objetos})


def registrarme(request):
    objetos = MiModelo.objects.all()
    return render(request, 'registrarme.html', {'objetos': objetos})

def inicio(request):
    objetos = MiModelo.objects.all()
    return render(request, 'inicio.html', {'objetos': objetos})

def configuracion(request):
    objetos = MiModelo.objects.all()
    return render(request, 'configuracion.html', {'objetos': objetos})

def inicio2(request):
    objetos = MiModelo.objects.all()
    return render(request, 'inicio2.html', {'objetos': objetos})

def configuracion2(request):
    objetos = MiModelo.objects.all()
    return render(request, 'configuracion2.html', {'objetos': objetos})

def ver3d(request):
    objetos = MiModelo.objects.all()
    return render(request, 'ver3d.html', {'objetos': objetos})

def ver3d2(request):
    objetos = MiModelo.objects.all()
    return render(request, 'ver3d2.html', {'objetos': objetos})